module.exports = {
    HOST:"localhost",
    USER: "beatriz",
    PASSWORD:"your_password",
    DB:"db_livros",
    dialect: "mysql",
    pool: {
        max:5,
        min:0,
        acquire:30000,
        idle:10000
    }
};